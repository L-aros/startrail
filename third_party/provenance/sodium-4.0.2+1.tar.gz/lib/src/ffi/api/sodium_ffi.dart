import 'dart:async';
import 'dart:ffi';
import 'dart:isolate';
import 'dart:typed_data';

import 'package:ffi/ffi.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../api/crypto.dart';
import '../../api/key_pair.dart';
import '../../api/randombytes.dart';
import '../../api/secure_key.dart';
import '../../api/sodium.dart';
import '../../api/sodium_exception.dart';
import '../../api/sodium_version.dart';
import '../../api/transferrable_secure_key.dart';
import '../bindings/libsodium.ffi.wrapper.dart';
import '../bindings/memory_protection.dart';
import '../bindings/sodium_finalizer.dart';
import '../bindings/sodium_pointer.dart';
import 'crypto_ffi.dart';
import 'helpers/isolates/isolate_result.dart';
import 'helpers/isolates/transferrable_key_pair_ffi.dart';
import 'helpers/isolates/transferrable_secure_key_ffi.dart';
import 'randombytes_ffi.dart';
import 'secure_key_ffi.dart';

/// @nodoc
@internal
typedef SodiumFFIIsolateCallback<TResult, TSodium extends SodiumFFI> =
    FutureOr<TResult> Function(
      TSodium sodium,
      List<SecureKey> secureKeys,
      List<KeyPair> keyPairs,
    );

/// @nodoc
@internal
typedef SodiumFFIFactory<TSodiumFFI extends SodiumFFI> =
    TSodiumFFI Function(LibSodiumFFI sodium);

/// @nodoc
@internal
class SodiumFFI implements Sodium {
  /// @nodoc
  final LibSodiumFFI sodium;

  /// @nodoc
  SodiumFFI([this.sodium = const LibSodiumFFI()]);

  @override
  SodiumVersion get version => SodiumVersion(
    sodium.sodium_library_version_major(),
    sodium.sodium_library_version_minor(),
    sodium.sodium_version_string().cast<Utf8>().toDartString(),
  );

  @override
  Uint8List pad(Uint8List buf, int blocksize) {
    final maxLen = buf.length + blocksize;
    SodiumPointer<UnsignedChar>? extendedBuffer;
    SodiumPointer<Size>? paddedLength;
    try {
      extendedBuffer = SodiumPointer.alloc(sodium, count: maxLen)..fill(buf);
      paddedLength = SodiumPointer.alloc(sodium, zeroMemory: true);
      final result = sodium.sodium_pad(
        paddedLength.ptr,
        extendedBuffer.ptr,
        buf.length,
        blocksize,
        maxLen,
      );
      SodiumException.checkSucceededInt(result);
      return Uint8List.sublistView(
        extendedBuffer.asListView<Uint8List>(owned: true),
        0,
        paddedLength.ptr.value,
      );
    } catch (_) {
      extendedBuffer?.dispose();
      rethrow;
    } finally {
      paddedLength?.dispose();
    }
  }

  @override
  Uint8List unpad(Uint8List buf, int blocksize) {
    SodiumPointer<UnsignedChar>? extendedBuffer;
    SodiumPointer<Size>? unpaddedLength;
    try {
      extendedBuffer = buf.toSodiumPointer(
        sodium,
        memoryProtection: MemoryProtection.readOnly,
      );
      unpaddedLength = SodiumPointer.alloc(sodium, zeroMemory: true);
      final result = sodium.sodium_unpad(
        unpaddedLength.ptr,
        extendedBuffer.ptr,
        extendedBuffer.count,
        blocksize,
      );
      SodiumException.checkSucceededInt(result);
      return Uint8List.sublistView(
        extendedBuffer.asListView<Uint8List>(owned: true),
        0,
        unpaddedLength.ptr.value,
      );
    } catch (_) {
      extendedBuffer?.dispose();
      rethrow;
    } finally {
      unpaddedLength?.dispose();
    }
  }

  @override
  SecureKey secureAlloc(int length) => SecureKeyFFI.alloc(sodium, length);

  @override
  SecureKey secureRandom(int length) => SecureKeyFFI.random(sodium, length);

  @override
  SecureKey secureCopy(Uint8List data) => SecureKeyFFI(
    data.toSodiumPointer(sodium, memoryProtection: MemoryProtection.noAccess),
  );

  @override
  late final Randombytes randombytes = RandombytesFFI(sodium);

  @override
  late final Crypto crypto = CryptoFFI(sodium);

  @override
  Future<T> runIsolated<T>(
    SodiumIsolateCallback<T> callback, {
    List<SecureKey> secureKeys = const [],
    List<KeyPair> keyPairs = const [],
  }) async => await runIsolatedWithFactory<T, SodiumFFI>(
    this,
    callback,
    secureKeys,
    keyPairs,
  );

  @override
  TransferrableSecureKey createTransferrableSecureKey(SecureKey secureKey) =>
      TransferrableSecureKeyFFI(secureKey);

  @override
  SecureKey materializeTransferrableSecureKey(
    TransferrableSecureKey transferrableSecureKey,
  ) {
    if (transferrableSecureKey case TransferrableSecureKeyFFI()) {
      return transferrableSecureKey.toSecureKey(this);
    } else {
      throw SodiumException(
        'Cannot materialize instance of type: '
        '${transferrableSecureKey.runtimeType}',
      );
    }
  }

  @override
  TransferrableKeyPair createTransferrableKeyPair(KeyPair keyPair) =>
      TransferrableKeyPairFFI(keyPair);

  @override
  KeyPair materializeTransferrableKeyPair(
    TransferrableKeyPair transferrableKeyPair,
  ) {
    if (transferrableKeyPair case TransferrableKeyPairFFI()) {
      return transferrableKeyPair.toKeyPair(this);
    } else {
      throw SodiumException(
        'Cannot materialize instance of type: '
        '${transferrableKeyPair.runtimeType}',
      );
    }
  }

  @protected
  Future<TResult> runIsolatedWithFactory<TResult, TSodiumFFI extends SodiumFFI>(
    TSodiumFFI sodium,
    SodiumIsolateCallback<TResult> callback,
    List<SecureKey> secureKeys,
    List<KeyPair> keyPairs,
  ) async {
    final isolateResult = await _isolateRun<TResult, TSodiumFFI>(
      sodium,
      secureKeys.map(TransferrableSecureKeyFFI.new).toList(),
      keyPairs.map(TransferrableKeyPairFFI.new).toList(),
      callback,
    );
    return isolateResult.extract(this);
  }

  static Future<IsolateResult<TResult>>
  _isolateRun<TResult, TSodium extends SodiumFFI>(
    TSodium sodium,
    List<TransferrableSecureKeyFFI> transferableSecureKeys,
    List<TransferrableKeyPairFFI> transferableKeyPairs,
    SodiumIsolateCallback<TResult> callback,
  ) async {
    SodiumFinalizer? debugOverwriteFinalizer;
    // ignore: prefer_asserts_with_message for debug only code
    assert(() {
      // ignore: invalid_use_of_visible_for_testing_member for debug only code
      final maybeOverwrittenFinalizer = SodiumPointer.debugOverwriteFinalizer;
      if (maybeOverwrittenFinalizer.runtimeType != SodiumFinalizer) {
        debugOverwriteFinalizer = maybeOverwrittenFinalizer;
      }
      return true;
    }());

    return await Isolate.run(debugName: 'SodiumFFI.runIsolated', () async {
      // ignore: prefer_asserts_with_message for debug only code
      assert(() {
        if (debugOverwriteFinalizer != null) {
          // ignore: invalid_use_of_visible_for_testing_member for debug only code
          SodiumPointer.debugOverwriteFinalizer = debugOverwriteFinalizer!;
          // ignore: avoid_print for debug only code
          print(
            '################################################################\n'
            '###                      !!! WARNING !!!                     ###\n'
            '###                                                          ###\n'
            '### Found SodiumPointer.debugOverwriteFinalizer that is used ###\n'
            '### to mock finalization of objects. If you see this message ###\n'
            '### in a non-test environment, it means that some code is    ###\n'
            '### mocking the finalization of SodiumPointer objects which  ###\n'
            '### can finalization of SodiumPointer objects which can lead ###\n'
            '### to memory leaks! Make sure that you are not mocking      ###\n'
            '### SodiumPointer.finalizer in production.                   ###\n'
            '################################################################',
          );
        }
        return true;
      }());

      final restoredSecureKeys = transferableSecureKeys
          .map((transferKey) => transferKey.toSecureKey(sodium))
          .toList();
      final restoredKeyPairs = transferableKeyPairs
          .map((transferKeyPair) => transferKeyPair.toKeyPair(sodium))
          .toList();

      try {
        final result = await callback(restoredSecureKeys, restoredKeyPairs);

        IsolateResult<TResult> isolateResult;
        switch (result) {
          case SecureKey():
            isolateResult = IsolateResult<TResult>.key(
              TransferrableSecureKeyFFI(result),
            );
            result.dispose();
          case KeyPair():
            isolateResult = IsolateResult<TResult>.keyPair(
              TransferrableKeyPairFFI(result),
            );
            result.dispose();
          case Uint8List():
            isolateResult = IsolateResult<TResult>.bytes(
              TransferableTypedData.fromList([result]),
            );
          default:
            isolateResult = IsolateResult<TResult>(result);
        }
        return isolateResult;
      } finally {
        for (final key in restoredSecureKeys) {
          key.dispose();
        }
        for (final keyPair in restoredKeyPairs) {
          keyPair.dispose();
        }
      }
    });
  }
}
