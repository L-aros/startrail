// Copyright (c) 2023, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

#include <stdio.h>

int main() {
#ifdef DEBUG
  printf("Running in debug mode.\n");
#endif
  printf("Hello world.\n");
  return 0;
}
